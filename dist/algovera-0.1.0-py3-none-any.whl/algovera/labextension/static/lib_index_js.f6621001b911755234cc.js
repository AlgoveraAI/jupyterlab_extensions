"use strict";
(self["webpackChunkalgovera"] = self["webpackChunkalgovera"] || []).push([
  ["lib_index_js"],
  {
    /***/ "./lib/index.js":
      /*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ MODULE_NAME: () =>
            /* reexport safe */ _version__WEBPACK_IMPORTED_MODULE_0__.MODULE_NAME,
          /* harmony export */ MODULE_VERSION: () =>
            /* reexport safe */ _version__WEBPACK_IMPORTED_MODULE_0__.MODULE_VERSION,
          /* harmony export */ CommandPaletteModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.CommandPaletteModel,
          /* harmony export */ CommandRegistryModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.CommandRegistryModel,
          /* harmony export */ JupyterFrontEndModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.JupyterFrontEndModel,
          /* harmony export */ PanelModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.PanelModel,
          /* harmony export */ SessionManagerModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.SessionManagerModel,
          /* harmony export */ ShellModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.ShellModel,
          /* harmony export */ SplitPanelModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.SplitPanelModel,
          /* harmony export */ SplitPanelView: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.SplitPanelView,
          /* harmony export */ TitleModel: () =>
            /* reexport safe */ _widget__WEBPACK_IMPORTED_MODULE_1__.TitleModel,
          /* harmony export */
        });
        /* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! ./version */ "./lib/version.js");
        /* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(/*! ./widget */ "./lib/widget.js");
        // Copyright (c) ipylab contributors
        // Distributed under the terms of the Modified BSD License.

        //# sourceMappingURL=index.js.map

        /***/
      },
  },
]);
//# sourceMappingURL=lib_index_js.f6621001b911755234cc.js.map
