"use strict";
(self["webpackChunkalgovera"] = self["webpackChunkalgovera"] || []).push([
  ["style_style_js"],
  {
    /***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
      /*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
      /***/ (module, __webpack_exports__, __webpack_require__) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ default: () => __WEBPACK_DEFAULT_EXPORT__,
          /* harmony export */
        });
        /* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js"
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__
          );
        // Imports

        var ___CSS_LOADER_EXPORT___ =
          _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()(
            _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()
          );
        // Module
        ___CSS_LOADER_EXPORT___.push([
          module.id,
          "",
          "",
          { version: 3, sources: [], names: [], mappings: "", sourceRoot: "" },
        ]);
        // Exports
        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ =
          ___CSS_LOADER_EXPORT___;

        /***/
      },

    /***/ "./node_modules/css-loader/dist/cjs.js!./style/widget.css":
      /*!****************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/widget.css ***!
  \****************************************************************/
      /***/ (module, __webpack_exports__, __webpack_require__) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ default: () => __WEBPACK_DEFAULT_EXPORT__,
          /* harmony export */
        });
        /* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js"
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js"
          );
        /* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__
          );
        // Imports

        var ___CSS_LOADER_EXPORT___ =
          _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()(
            _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()
          );
        // Module
        ___CSS_LOADER_EXPORT___.push([
          module.id,
          "/*-----------------------------------------------------------------------------\n| Copyright (c) ipylab contributors.\n| Distributed under the terms of the Modified BSD License.\n|----------------------------------------------------------------------------*/\n\n/* Default Split Handle Color*/\n.jp-JupyterLuminoSplitPanelWidget .p-SplitPanel-handle {\n  background-color: var(--jp-border-color2);\n}\n\n.jp-SideAreaWidget {\n  background: var(--jp-layout-color1);\n  display: flex;\n}\n\n.jp-SideBar.jp-mod-left .p-mod-closable .p-TabBar-tabCloseIcon,\n.jp-SideBar.jp-mod-right .p-mod-closable .p-TabBar-tabCloseIcon {\n  padding: 4px 0px 4px 4px;\n  background-size: 16px;\n  height: 16px;\n  width: 16px;\n  background-image: var(--jp-icon-close);\n  background-position: center;\n  background-repeat: no-repeat;\n  align-self: center;\n}\n\n.jp-SideBar.jp-mod-left .p-mod-closable .p-TabBar-tabCloseIcon:hover,\n.jp-SideBar.jp-mod-right .p-mod-closable .p-TabBar-tabCloseIcon:hover {\n  background-size: 16px;\n  background-image: var(--jp-icon-inverse-close-circle);\n}\n",
          "",
          {
            version: 3,
            sources: ["webpack://./style/widget.css"],
            names: [],
            mappings:
              "AAAA;;;8EAG8E;;AAE9E,8BAA8B;AAC9B;EACE,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,aAAa;AACf;;AAEA;;EAEE,wBAAwB;EACxB,qBAAqB;EACrB,YAAY;EACZ,WAAW;EACX,sCAAsC;EACtC,2BAA2B;EAC3B,4BAA4B;EAC5B,kBAAkB;AACpB;;AAEA;;EAEE,qBAAqB;EACrB,qDAAqD;AACvD",
            sourcesContent: [
              "/*-----------------------------------------------------------------------------\n| Copyright (c) ipylab contributors.\n| Distributed under the terms of the Modified BSD License.\n|----------------------------------------------------------------------------*/\n\n/* Default Split Handle Color*/\n.jp-JupyterLuminoSplitPanelWidget .p-SplitPanel-handle {\n  background-color: var(--jp-border-color2);\n}\n\n.jp-SideAreaWidget {\n  background: var(--jp-layout-color1);\n  display: flex;\n}\n\n.jp-SideBar.jp-mod-left .p-mod-closable .p-TabBar-tabCloseIcon,\n.jp-SideBar.jp-mod-right .p-mod-closable .p-TabBar-tabCloseIcon {\n  padding: 4px 0px 4px 4px;\n  background-size: 16px;\n  height: 16px;\n  width: 16px;\n  background-image: var(--jp-icon-close);\n  background-position: center;\n  background-repeat: no-repeat;\n  align-self: center;\n}\n\n.jp-SideBar.jp-mod-left .p-mod-closable .p-TabBar-tabCloseIcon:hover,\n.jp-SideBar.jp-mod-right .p-mod-closable .p-TabBar-tabCloseIcon:hover {\n  background-size: 16px;\n  background-image: var(--jp-icon-inverse-close-circle);\n}\n",
            ],
            sourceRoot: "",
          },
        ]);
        // Exports
        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ =
          ___CSS_LOADER_EXPORT___;

        /***/
      },

    /***/ "./style/base.css":
      /*!************************!*\
  !*** ./style/base.css ***!
  \************************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ default: () => __WEBPACK_DEFAULT_EXPORT__,
          /* harmony export */
        });
        /* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
          );
        /* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css"
          );

        var options = {};

        options.insert = "head";
        options.singleton = false;

        var update =
          _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(
            _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__[
              "default"
            ],
            options
          );

        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ =
          _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__[
            "default"
          ].locals || {};

        /***/
      },

    /***/ "./style/widget.css":
      /*!**************************!*\
  !*** ./style/widget.css ***!
  \**************************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony export */ __webpack_require__.d(__webpack_exports__, {
          /* harmony export */ default: () => __WEBPACK_DEFAULT_EXPORT__,
          /* harmony export */
        });
        /* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(
            /*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js"
          );
        /* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default =
          /*#__PURE__*/ __webpack_require__.n(
            _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__
          );
        /* harmony import */ var _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(
            /*! !!../node_modules/css-loader/dist/cjs.js!./widget.css */ "./node_modules/css-loader/dist/cjs.js!./style/widget.css"
          );

        var options = {};

        options.insert = "head";
        options.singleton = false;

        var update =
          _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(
            _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_1__[
              "default"
            ],
            options
          );

        /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ =
          _node_modules_css_loader_dist_cjs_js_widget_css__WEBPACK_IMPORTED_MODULE_1__[
            "default"
          ].locals || {};

        /***/
      },

    /***/ "./style/style.js":
      /*!************************!*\
  !*** ./style/style.js ***!
  \************************/
      /***/ (
        __unused_webpack_module,
        __webpack_exports__,
        __webpack_require__
      ) => {
        __webpack_require__.r(__webpack_exports__);
        /* harmony import */ var _widget_css__WEBPACK_IMPORTED_MODULE_0__ =
          __webpack_require__(/*! ./widget.css */ "./style/widget.css");
        /* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_1__ =
          __webpack_require__(/*! ./base.css */ "./style/base.css");

        /***/
      },
  },
]);
//# sourceMappingURL=style_style_js.d00d12a32cb5898f6fb0.js.map
