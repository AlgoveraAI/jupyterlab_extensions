(self["webpackChunkalgovera"] = self["webpackChunkalgovera"] || []).push([
  ["_4afa"],
  {
    /***/ "?4afa":
      /*!************************!*\
  !*** buffer (ignored) ***!
  \************************/
      /***/ () => {
        /* (ignored) */
        /***/
      },
  },
]);
//# sourceMappingURL=_4afa.358ba94cf4ce009c8966.js.map
